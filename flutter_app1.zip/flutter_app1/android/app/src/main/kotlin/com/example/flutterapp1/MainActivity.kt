package com.example.flutterapp1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
